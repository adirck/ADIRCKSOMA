------cancelar nota da venda cancela------
update a set a.STATUS_NFE ='52',a.MOTIVO_CANCELAMENTO_NFE='nota fiscal gerada com erro do sistema ',NOTA_CANCELADA='1',a.LOG_STATUS_NFE='0'
from LOJA_NOTA_FISCAL a (nolock)
left  join loja_venda_pgto b (nolock) on a.CODIGO_FILIAL= b.CODIGO_FILIAL and a.SERIE_NF =b.SERIE_NF_SAIDA and a.NF_NUMERO =b.NUMERO_FISCAL_VENDA 
left  join LOJA_VENDA c (nolock) on a.CODIGO_FILIAL= b.CODIGO_FILIAL and b.TERMINAL =c.TERMINAL and b.LANCAMENTO_CAIXA =c.LANCAMENTO_CAIXA
where 
a.STATUS_NFE not in('5','59','49','70','50') 
and c.MOTIVO_CANCELAMENTO is not null and b.VENDA_FINALIZADA='1'
and a.EMISSAO >= (getdate()-2)  and a.SERIE_NF ='65'

--------box  inutilizar -------------
update  a set a.STATUS_NFE ='52',a.MOTIVO_CANCELAMENTO_NFE='nota fiscal com erro sistema box',NOTA_CANCELADA='1',a.LOG_STATUS_NFE='0'
from LOJA_NOTA_FISCAL a (nolock)
left  join loja_venda_pgto b (nolock) on a.CODIGO_FILIAL= b.CODIGO_FILIAL and a.PEDIDO_WMS =b.PEDIDO_WMS 
where 
a.STATUS_NFE not in('5','59','49','70','50') 
and b.PEDIDO_WMS is null
and a.EMISSAO >= (getdate()-2) and a.SERIE_NF ='65'