update loja_nota_fiscal
set status_NFe = '1',log_status_nfe = '0',DATA_PARA_TRANSFERENCIA = GETDATE ()
where EMISSAO >= (getdate()-2) and STATUS_NFE not in('5','59','49','70','50','52','42') and SERIE_NF <>'65'
