
/****** Object:  UserDefinedFunction [dbo].[FXANM_ConsultaVarString]    Script Date: 09/12/2025 15:29:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE OR ALTER FUNCTION [dbo].[FXANM_ConsultaVarString] ( @array VARCHAR(8000) )
RETURNS @Table TABLE ( Valores VARCHAR(200) )
AS 
    BEGIN
        DECLARE @separador_posicao INTEGER,
            @array_value VARCHAR(8000)  

        SET @array = @array + ','

        WHILE PATINDEX('%,%', @array) <> 0 
            BEGIN
                SELECT  @separador_posicao = PATINDEX('%,%', @array)
                SELECT  @array_value = LEFT(@array, @separador_posicao - 1)

                INSERT  @Table
                VALUES  ( RTRIM(LTRIM(@array_value)) )

                SELECT  @array = STUFF(@array, 1, @separador_posicao, '')
            END
        RETURN
    END











GO


