/****** Object:  Trigger [dbo].[LXU_LOJA_SAIDAS]    Script Date: 19/07/2018 19:40:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER TRIGGER [dbo].[LXU_LOJA_SAIDAS] ON [dbo].[LOJA_SAIDAS] FOR UPDATE NOT FOR REPLICATION AS
-- UPDATE trigger on LOJA_SAIDAS

-- FELIPE SILVA   - (SS02) - 22/03/2016 - ENCERRA A SA�DA CASO A NOTA FISCAL J� TENHA SIDO EMITIDA.*/
/* Tiago Carvalho (SS) : 29/01/2016 - N�o deixo encerrar a sa�da sem nota fiscal caso */
-- 22/03/2013 - Diego Moreno - TP 3530142 - #01# - Passou a n�o atualizar a data_para_transferencias das consigna�oes na tabela LOJA_SAIDAS.
begin
  declare  @numrows int,
           @nullcnt int,
           @validcnt int,
           @insROMANEIO_PRODUTO char(15), 
           @insFILIAL varchar(25),
           @delROMANEIO_PRODUTO char(15), 
           @delFILIAL varchar(25),
           @errno   int,
           @errmsg  varchar(255)

  select @numrows = @@rowcount
  ------SOMA - removido 
	--/*SS02 - ENCERRA A SA�DA CASO A NOTA FISCAL J� TENHA SIDO EMITIDA.*/
	--DECLARE @NrRomaneioProduto CHAR(15), 
	--		@FilialSaida VARCHAR(25), 
	--		@NumeroNfTransferencia CHAR(15),
	--		@SaidaEncerrada BIT
			
	--DECLARE CurInserted CURSOR FOR
 --   SELECT ROMANEIO_PRODUTO, FILIAL, NUMERO_NF_TRANSFERENCIA, SAIDA_ENCERRADA FROM INSERTED
    
 --   OPEN CurInserted
 --   FETCH NEXT FROM CurInserted INTO @NrRomaneioProduto, @FilialSaida, @NumeroNfTransferencia, @SaidaEncerrada
         
 --   WHILE @@FETCH_STATUS = 0
 --   BEGIN
	--	IF ISNULL(@NumeroNfTransferencia, '') <> '' AND @SaidaEncerrada = 0
	--	BEGIN 
	--		UPDATE LOJA_SAIDAS SET SAIDA_ENCERRADA = 1 WHERE ROMANEIO_PRODUTO = @NrRomaneioProduto AND FILIAL = @FilialSaida	
	--	END 
	--	FETCH NEXT FROM CurInserted INTO @NrRomaneioProduto, @FilialSaida,@NumeroNfTransferencia, @SaidaEncerrada
 --   END
 --   CLOSE CurInserted
 --   DEALLOCATE CurInserted
 --   /*FIM SS02*/
  
--- Verifica bloqueio por contagem ------------------------------------------------------------------------------
	IF UPDATE(FILIAL) OR UPDATE(EMISSAO)
	BEGIN
		IF EXISTS (SELECT 
				Inserted.EMISSAO 
			FROM 
				Inserted 
				INNER JOIN LOJA_SAIDAS_PRODUTO ON Inserted.FILIAL = LOJA_SAIDAS_PRODUTO.FILIAL AND Inserted.ROMANEIO_PRODUTO = LOJA_SAIDAS_PRODUTO.ROMANEIO_PRODUTO 
				INNER JOIN ESTOQUE_PRODUTOS ON ESTOQUE_PRODUTOS.FILIAL = Inserted.FILIAL AND ESTOQUE_PRODUTOS.PRODUTO = LOJA_SAIDAS_PRODUTO.PRODUTO AND ESTOQUE_PRODUTOS.COR_PRODUTO = LOJA_SAIDAS_PRODUTO.COR_PRODUTO 
			WHERE 
				Inserted.EMISSAO < ESTOQUE_PRODUTOS.DATA_AJUSTE) 
			AND EXISTS (SELECT 
				Deleted.EMISSAO
			FROM 
				Deleted 
				INNER JOIN LOJA_SAIDAS_PRODUTO ON Deleted.FILIAL = LOJA_SAIDAS_PRODUTO.FILIAL AND Deleted.ROMANEIO_PRODUTO = LOJA_SAIDAS_PRODUTO.ROMANEIO_PRODUTO 
				INNER JOIN ESTOQUE_PRODUTOS ON ESTOQUE_PRODUTOS.FILIAL = Deleted.FILIAL AND ESTOQUE_PRODUTOS.PRODUTO = LOJA_SAIDAS_PRODUTO.PRODUTO AND ESTOQUE_PRODUTOS.COR_PRODUTO = LOJA_SAIDAS_PRODUTO.COR_PRODUTO 
			WHERE 
				Deleted.EMISSAO < ESTOQUE_PRODUTOS.DATA_AJUSTE)
		BEGIN
			SELECT @errno = 30002, @errmsg = 'N�o � poss�vel alterar movimenta��o de estoque anterior ao ajuste.'
			GoTo Error
		END
	END
-----------------------------------------------------------------------------------------------------------------

/* LOJA_TIPOS_ENTRADA_SAIDA R/1307 LOJA_SAIDAS ON CHILD UPDATE RESTRICT */
  if
    update(TIPO_ENTRADA_SAIDA)
  begin
    select @nullcnt = 0
    select @validcnt = count(*)
      from inserted,LOJA_TIPOS_ENTRADA_SAIDA
     where
           inserted.TIPO_ENTRADA_SAIDA = LOJA_TIPOS_ENTRADA_SAIDA.TIPO_ENTRADA_SAIDA
    select @nullcnt = count(*) from inserted where
      inserted.TIPO_ENTRADA_SAIDA is null
    if @validcnt + @nullcnt != @numrows
    begin
      select @errno  = 30007,
             @errmsg = 'Imposs�vel atualizar  "LOJA_SAIDAS" porque "LOJA_TIPOS_ENTRADA_SAIDA" n�o existe.'
      goto error
    end
  end

/* FILIAIS FILIAL_DESTINO LOJA_SAIDAS ON CHILD UPDATE RESTRICT */
  if
    update(FILIAL_DESTINO)
  begin
    select @nullcnt = 0
    select @validcnt = count(*)
      from inserted,FILIAIS
     where
           inserted.FILIAL_DESTINO = FILIAIS.FILIAL
    select @nullcnt = count(*) from inserted where
      inserted.FILIAL_DESTINO is null
    if @validcnt + @nullcnt != @numrows
    begin
      select @errno  = 30007,
             @errmsg = 'Imposs�vel atualizar  "LOJA_SAIDAS" porque "FILIAIS" n�o existe.'
      goto error
    end
  end

/* FILIAIS R/1174 LOJA_SAIDAS ON CHILD UPDATE RESTRICT */
  if
    update(FILIAL)
  begin
    select @nullcnt = 0
    select @validcnt = count(*)
      from inserted,FILIAIS
     where
           inserted.FILIAL = FILIAIS.FILIAL
    
    if @validcnt + @nullcnt != @numrows
    begin
      select @errno  = 30007,
             @errmsg = 'Imposs�vel atualizar  "LOJA_SAIDAS" porque "FILIAIS" n�o existe.'
      goto error
    end
  end


/* LOJA_SAIDAS R/1190 LOJA_SAIDAS_PRODUTO ON PARENT UPDATE CASCADE */
  IF 
     update(ROMANEIO_PRODUTO) OR 
     update(FILIAL)
  BEGIN
    DECLARE LOJA_SAIDAS1919 CURSOR FOR SELECT ROMANEIO_PRODUTO,
                                              FILIAL FROM INSERTED
    DECLARE LOJA_SAIDAS1120 CURSOR FOR SELECT ROMANEIO_PRODUTO,
                                              FILIAL FROM DELETED
    OPEN LOJA_SAIDAS1919
    OPEN LOJA_SAIDAS1120
    FETCH NEXT FROM LOJA_SAIDAS1919 INTO @insROMANEIO_PRODUTO,
                                         @insFILIAL
    FETCH NEXT FROM LOJA_SAIDAS1120 INTO @delROMANEIO_PRODUTO,
                                         @delFILIAL
    IF @@rowcount >= 0
    BEGIN
      WHILE @@fetch_status = 0
      BEGIN
        UPDATE LOJA_SAIDAS_PRODUTO
           SET LOJA_SAIDAS_PRODUTO.ROMANEIO_PRODUTO=@insROMANEIO_PRODUTO,
               LOJA_SAIDAS_PRODUTO.FILIAL=@insFILIAL
         WHERE LOJA_SAIDAS_PRODUTO.ROMANEIO_PRODUTO = @delROMANEIO_PRODUTO and
               LOJA_SAIDAS_PRODUTO.FILIAL = @delFILIAL

        FETCH NEXT FROM LOJA_SAIDAS1919 INTO @insROMANEIO_PRODUTO,
                                             @insFILIAL
        FETCH NEXT FROM LOJA_SAIDAS1120 INTO @delROMANEIO_PRODUTO,
                                             @delFILIAL
      END
    END
    CLOSE LOJA_SAIDAS1919
    CLOSE LOJA_SAIDAS1120
    DEALLOCATE LOJA_SAIDAS1919
    DEALLOCATE LOJA_SAIDAS1120
  END

--- Verifica sa�da encerrada ------------------------------------------------------------------------------------
	IF UPDATE(SAIDA_ENCERRADA)
	BEGIN
		IF EXISTS (SELECT 
				1 
			FROM 
				DELETED 
				INNER JOIN INSERTED ON DELETED.ROMANEIO_PRODUTO = INSERTED.ROMANEIO_PRODUTO AND DELETED.FILIAL = INSERTED.FILIAL 
			WHERE
				DELETED.SAIDA_ENCERRADA = 1 AND ISNULL(INSERTED.SAIDA_ENCERRADA, 0) = 0)
		BEGIN
			SELECT @errno = 30002, @errmsg = 'N�o � poss�vel reabrir uma movimenta��o encerrada.'
			GOTO Error
		END
		ELSE
		BEGIN
			DECLARE @cProduto Char(12), @cCor_Produto Char(10), @cFilial VarChar(25), @nEstoque Int, 
				@nEs1  Int, @nEs2  Int, @nEs3  Int, @nEs4  Int, @nEs5  Int, @nEs6  Int, @nEs7  Int, @nEs8  Int,
				@nEs9  Int, @nEs10 Int, @nEs11 Int, @nEs12 Int, @nEs13 Int, @nEs14 Int, @nEs15 Int, @nEs16 Int,
				@nEs17 Int, @nEs18 Int, @nEs19 Int, @nEs20 Int, @nEs21 Int, @nEs22 Int, @nEs23 Int, @nEs24 Int, 
				@nEs25 Int, @nEs26 Int, @nEs27 Int, @nEs28 Int, @nEs29 Int, @nEs30 Int, @nEs31 Int, @nEs32 Int, 
				@nEs33 Int, @nEs34 Int, @nEs35 Int, @nEs36 Int, @nEs37 Int, @nEs38 Int, @nEs39 Int, @nEs40 Int, 
				@nEs41 Int, @nEs42 Int, @nEs43 Int, @nEs44 Int, @nEs45 Int, @nEs46 Int, @nEs47 Int, @nEs48 Int

			DECLARE curSAIDA_ENCERRADA CURSOR FOR
			SELECT 
				PRODUTO, COR_PRODUTO, INSERTED.FILIAL, 
				SUM(EN1), SUM(EN2), SUM(EN3), SUM(EN4), SUM(EN5), SUM(EN6), SUM(EN7), SUM(EN8), 
				SUM(EN9), SUM(EN10), SUM(EN11), SUM(EN12), SUM(EN13), SUM(EN14), SUM(EN15), SUM(EN16), 
				SUM(EN17), SUM(EN18), SUM(EN19), SUM(EN20), SUM(EN21), SUM(EN22), SUM(EN23), SUM(EN24), 
				SUM(EN25), SUM(EN26), SUM(EN27), SUM(EN28), SUM(EN29), SUM(EN30), SUM(EN31), SUM(EN32), 
				SUM(EN33), SUM(EN34), SUM(EN35), SUM(EN36), SUM(EN37), SUM(EN38), SUM(EN39), SUM(EN40), 
				SUM(EN41), SUM(EN42), SUM(EN43), SUM(EN44), SUM(EN45), SUM(EN46), SUM(EN47), SUM(EN48) 
			FROM 
				INSERTED  
				INNER JOIN DELETED ON INSERTED.ROMANEIO_PRODUTO = DELETED.ROMANEIO_PRODUTO AND INSERTED.FILIAL = DELETED.FILIAL 
				INNER JOIN LOJA_SAIDAS_PRODUTO ON INSERTED.FILIAL = LOJA_SAIDAS_PRODUTO.FILIAL AND INSERTED.ROMANEIO_PRODUTO = LOJA_SAIDAS_PRODUTO.ROMANEIO_PRODUTO 
			WHERE 
				INSERTED.SAIDA_ENCERRADA = 1 AND DELETED.SAIDA_ENCERRADA = 0 
			GROUP BY 
				PRODUTO, COR_PRODUTO, INSERTED.FILIAL

			OPEN curSAIDA_ENCERRADA

			FETCH NEXT FROM curSAIDA_ENCERRADA INTO @cProduto, @cCor_Produto, @cFilial, 
				@nEs1,  @nEs2,  @nEs3,  @nEs4,  @nEs5,  @nEs6,  @nEs7,  @nEs8,  @nEs9,  @nEs10, @nEs11, @nEs12, 
				@nEs13, @nEs14, @nEs15, @nEs16, @nEs17, @nEs18, @nEs19, @nEs20, @nEs21, @nEs22, @nEs23, @nEs24, 
				@nEs25, @nEs26, @nEs27, @nEs28, @nEs29, @nEs30, @nEs31, @nEs32, @nEs33, @nEs34, @nEs35, @nEs36, 
				@nEs37, @nEs38, @nEs39, @nEs40, @nEs41, @nEs42, @nEs43, @nEs44, @nEs45, @nEs46, @nEs47, @nEs48

			WHILE (@@FETCH_STATUS = 0)
			BEGIN
				SELECT @nEstoque = @nEs1 + @nEs2 + @nEs3 + @nEs4 + @nEs5 + @nEs6 + @nEs7 + @nEs8 + @nEs9 + @nEs10 + @nEs11 + @nEs12 + 
					@nEs13 + @nEs14 + @nEs15 + @nEs16 + @nEs17 + @nEs18 + @nEs19 + @nEs20 + @nEs21 + @nEs22 + @nEs23 + @nEs24 + 
					@nEs25 + @nEs26 + @nEs27 + @nEs28 + @nEs29 + @nEs30 + @nEs31 + @nEs32 + @nEs33 + @nEs34 + @nEs35 + @nEs36 + 
					@nEs37 + @nEs38 + @nEs39 + @nEs40 + @nEs41 + @nEs42 + @nEs43 + @nEs44 + @nEs45 + @nEs46 + @nEs47 + @nEs48

				IF (SELECT COUNT(*) FROM ESTOQUE_PRODUTOS WHERE PRODUTO = @cProduto AND COR_PRODUTO = @cCor_Produto AND FILIAL = @cFilial) > 0
					UPDATE 
						ESTOQUE_PRODUTOS
					SET 
						ESTOQUE = ESTOQUE - @nEstoque, ULTIMA_SAIDA = GETDATE(), 
						ES1 = ES1 - @nES1, ES2 = ES2 - @nES2, ES3 = ES3 - @nES3, ES4 = ES4 - @nES4, ES5 = ES5 - @nES5, ES6 = ES6 - @nES6, 
						ES7 = ES7 - @nES7, ES8 = ES8 - @nES8, ES9 = ES9 - @nES9, ES10 = ES10 - @nES10, ES11 = ES11 - @nES11, ES12 = ES12 - @nES12, 
						ES13 = ES13 - @nES13, ES14 = ES14 - @nES14, ES15 = ES15 - @nES15, ES16 = ES16 - @nES16, ES17 = ES17 - @nES17, ES18 = ES18 - @nES18, 
						ES19 = ES19 - @nES19, ES20 = ES20 - @nES20, ES21 = ES21 - @nES21, ES22 = ES22 - @nES22, ES23 = ES23 - @nES23, ES24 = ES24 - @nES24, 
						ES25 = ES25 - @nES25, ES26 = ES26 - @nES26, ES27 = ES27 - @nES27, ES28 = ES28 - @nES28, ES29 = ES29 - @nES29, ES30 = ES30 - @nES30, 
						ES31 = ES31 - @nES31, ES32 = ES32 - @nES32, ES33 = ES33 - @nES33, ES34 = ES34 - @nES34, ES35 = ES35 - @nES35, ES36 = ES36 - @nES36, 
						ES37 = ES37 - @nES37, ES38 = ES38 - @nES38, ES39 = ES39 - @nES39, ES40 = ES40 - @nES40, ES41 = ES41 - @nES41, ES42 = ES42 - @nES42, 
						ES43 = ES43 - @nES43, ES44 = ES44 - @nES44, ES45 = ES45 - @nES45, ES46 = ES46 - @nES46, ES47 = ES47 - @nES47, ES48 = ES48 - @nES48 
					WHERE 
						PRODUTO = @cProduto AND COR_PRODUTO = @cCor_Produto AND FILIAL = @cFilial
				ELSE
					INSERT INTO ESTOQUE_PRODUTOS 
						(PRODUTO, COR_PRODUTO, FILIAL, ESTOQUE, ULTIMA_SAIDA, 
						ES1,  ES2,  ES3,  ES4,  ES5,  ES6,  ES7,  ES8,  ES9,  ES10, ES11, ES12, ES13, ES14, ES15, ES16,  
						ES17, ES18, ES19, ES20, ES21, ES22, ES23, ES24, ES25, ES26, ES27, ES28, ES29, ES30, ES31, ES32,
						ES33, ES34, ES35, ES36, ES37, ES38, ES39, ES40, ES41, ES42, ES43, ES44, ES45, ES46, ES47, ES48)
					VALUES 
						(@cProduto, @cCor_Produto, @cFilial, @nEstoque * -1, GETDATE(), 
						@nEs1 * -1, @nEs2 * -1, @nEs3 * -1, @nEs4 * -1, @nEs5 * -1, @nEs6 * -1, @nEs7 * -1, @nEs8 * -1, 
						@nEs9 * -1, @nEs10 * -1, @nEs11 * -1, @nEs12 * -1, @nEs13 * -1, @nEs14 * -1, @nEs15 * -1, @nEs16 * -1, 
						@nEs17 * -1, @nEs18 * -1, @nEs19 * -1, @nEs20 * -1, @nEs21 * -1, @nEs22 * -1, @nEs23 * -1, @nEs24 * -1, 
						@nEs25 * -1, @nEs26 * -1, @nEs27 * -1, @nEs28 * -1, @nEs29 * -1, @nEs30 * -1, @nEs31 * -1, @nEs32 * -1, 
						@nEs33 * -1, @nEs34 * -1, @nEs35 * -1, @nEs36 * -1, @nEs37 * -1, @nEs38 * -1, @nEs39 * -1, @nEs40 * -1, 
						@nEs41 * -1, @nEs42 * -1, @nEs43 * -1, @nEs44 * -1, @nEs45 * -1, @nEs46 * -1, @nEs47 * -1, @nEs48 * -1)

				IF @@ROWCOUNT = 0
				BEGIN
					SELECT @errno = 30002, @errmsg = 'A opera��o foi cancelada. N�o foi poss�vel atualizar "ESTOQUE_PRODUTOS".'
					GOTO Error
				END

				FETCH NEXT FROM curSAIDA_ENCERRADA INTO @cProduto, @cCor_Produto, @cFilial, 
					@nEs1,  @nEs2,  @nEs3,  @nEs4,  @nEs5,  @nEs6,  @nEs7,  @nEs8,  @nEs9,  @nEs10, @nEs11, @nEs12, 
					@nEs13, @nEs14, @nEs15, @nEs16, @nEs17, @nEs18, @nEs19, @nEs20, @nEs21, @nEs22, @nEs23, @nEs24, 
					@nEs25, @nEs26, @nEs27, @nEs28, @nEs29, @nEs30, @nEs31, @nEs32, @nEs33, @nEs34, @nEs35, @nEs36, 
					@nEs37, @nEs38, @nEs39, @nEs40, @nEs41, @nEs42, @nEs43, @nEs44, @nEs45, @nEs46, @nEs47, @nEs48
			END
			
			CLOSE curSAIDA_ENCERRADA
			DEALLOCATE curSAIDA_ENCERRADA
		END
	END
-----------------------------------------------------------------------------------------------------------------
/*SS01 - N�o deixa salvar se a nota fiscal n�o for preenchida.*/
if exists (	select a.ROMANEIO_PRODUTO 
				from inserted a
				inner join deleted b
					on a.ROMANEIO_PRODUTO = b.ROMANEIO_PRODUTO and a.FILIAL = b.FILIAL
				inner join lojas_varejo lv
					on a.FILIAL = lv.FILIAL
				inner join FILIAIS origem 
					on a.FILIAL = lv.FILIAL
				inner join filiais destino
					on destino.FILIAL = isnull(a.FILIAL_DESTINO ,a.FORNECEDOR_DEVOLUCAO )
				inner join LOJA_SAIDAS c
					on a.ROMANEIO_PRODUTO = c.romaneio_produto and a.FILIAL = c.filial 
				where a.SAIDA_ENCERRADA = 1 
					and b.SAIDA_ENCERRADA = 0 
					and a.SAIDA_CANCELADA = 0 
					and origem.CGC_CPF <> destino.CGC_CPF
					and ltrim(rtrim(c.NUMERO_NF_TRANSFERENCIA)) =''
			)
		begin
			/*Tento recuperar o numero do LOJA_NOTA_FISCAL*/
			update c	
					set c.NUMERO_NF_TRANSFERENCIA = NF.NF_NUMERO
				from inserted a
				inner join deleted b
					on a.ROMANEIO_PRODUTO = b.ROMANEIO_PRODUTO and a.FILIAL = b.FILIAL
				inner join lojas_varejo lv
					on a.FILIAL = lv.FILIAL
				inner join FILIAIS origem 
					on a.FILIAL = lv.FILIAL
				inner join filiais destino
					on destino.FILIAL = isnull(a.FILIAL_DESTINO ,a.FORNECEDOR_DEVOLUCAO )
				inner join LOJA_SAIDAS c
					on a.ROMANEIO_PRODUTO = c.romaneio_produto and a.FILIAL = c.filial
				inner join LOJA_NOTA_FISCAL nf
					on nf.ROMANEIO_PRODUTO = a.ROMANEIO_PRODUTO and nf.CODIGO_FILIAL = lv.CODIGO_FILIAL 				
				where a.SAIDA_ENCERRADA = 1 
					and b.SAIDA_ENCERRADA = 0 
					and a.SAIDA_CANCELADA = 0 
					and origem.CGC_CPF <> destino.CGC_CPF
					and ltrim(rtrim(c.NUMERO_NF_TRANSFERENCIA)) =''
			
			
			if exists (	select a.ROMANEIO_PRODUTO 
						from inserted a
						inner join deleted b
							on a.ROMANEIO_PRODUTO = b.ROMANEIO_PRODUTO and a.FILIAL = b.FILIAL
						inner join lojas_varejo lv
							on a.FILIAL = lv.FILIAL
						inner join FILIAIS origem 
							on a.FILIAL = lv.FILIAL
						inner join filiais destino
							on destino.FILIAL = isnull(a.FILIAL_DESTINO ,a.FORNECEDOR_DEVOLUCAO )
						inner join LOJA_SAIDAS c
							on a.ROMANEIO_PRODUTO = c.romaneio_produto and a.FILIAL = c.filial 
						where a.SAIDA_ENCERRADA = 1 
							and b.SAIDA_ENCERRADA = 0 
							and a.SAIDA_CANCELADA = 0 
							and origem.CGC_CPF <> destino.CGC_CPF
							and ltrim(rtrim(c.NUMERO_NF_TRANSFERENCIA)) =''
					)		
				begin
					SELECT @errno = 30002, @errmsg = 'N�o � permitido encerrar uma sa�da sem n�mero de nota fiscal.'
					GOTO Error
				end
				
		end
	
/*---LINX-ETL------------------------------------------------------------------------------------------*/

IF EXISTS (SELECT 1 FROM inserted where inserted.TIPO_ENTRADA_SAIDA <> '06')	
	IF NOT UPDATE(LX_STATUS_SAIDA)
	BEGIN
		UPDATE LOJA_SAIDAS 
		SET LX_STATUS_SAIDA = 1, DATA_PARA_TRANSFERENCIA = INSERTED.DATA_PARA_TRANSFERENCIA  -- SINCRONIZA��O PENDENTE
		FROM LOJA_SAIDAS, INSERTED
		WHERE 	LOJA_SAIDAS.ROMANEIO_PRODUTO = INSERTED.ROMANEIO_PRODUTO and
				LOJA_SAIDAS.FILIAL = INSERTED.FILIAL 
	END

--- DATA PARA TRANSFERENCIA -------------------------------------------------------------------------------------
	IF EXISTS (SELECT 1 FROM inserted where inserted.TIPO_ENTRADA_SAIDA <> '06')		
		IF NOT UPDATE(DATA_PARA_TRANSFERENCIA)
			BEGIN
			UPDATE 	LOJA_SAIDAS 
			SET 	DATA_PARA_TRANSFERENCIA = GETDATE()
			FROM 	LOJA_SAIDAS, INSERTED
			WHERE 	LOJA_SAIDAS.ROMANEIO_PRODUTO = INSERTED.ROMANEIO_PRODUTO and
				LOJA_SAIDAS.FILIAL = INSERTED.FILIAL 
				AND (INSERTED.DATA_PARA_TRANSFERENCIA IS NULL 
				OR LOJA_SAIDAS.DATA_PARA_TRANSFERENCIA = INSERTED.DATA_PARA_TRANSFERENCIA)
		END
-----------------------------------------------------------------------------------------------------------------

	return
error:
    raiserror(@errmsg, 18, 1)
    rollback transaction
end


