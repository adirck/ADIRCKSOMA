** Procedimentos Para Compatibilizacao com o LinxPOS
** Adicionar Os Seguintes Comandos na Tela de Login
** Baseado no Script Login.Prg usado na Hering no ServicePack



*** Colocar dentro do ExecuteTasks

*!*	IF !DODEFAULT() THEN
*!*		RETURN .F.
*!*	ENDIF

*!*	LOCAL bFechaLinx as Boolean, eException as Exception

*!*	bFechaLinx = .F.

*!*	#Define _FXP_MOTOR_PROMO "Userprograms\MotorPromo\startuplinxpos.Fxp"

*!*	IF .Not. File(ADDBS(strDefaultDir)+_FXP_MOTOR_PROMO)
*!*		MsgBox("Arquivo de inicializa��o do motor de promo��es n�o encontrado. Avise Imediatamento o Suporte!",16,"Erro Login")
*!*		bFechaLinx = .T.
*!*	Endif

*!*	Set Procedure To (ADDBS(strDefaultDir)+_FXP_MOTOR_PROMO) Additive

*!*	TRY
*!*		bFechaLinx = .Not.RegistrarComponentesHering()

*!*	CATCH TO eException
*!*		MsgBox("Falha na inicializa��o do motor de promo��es.\nErro: "+eException.Message+"\n\nAvise Imediatamento o Suporte",16,"Erro ExecuteTasks")
*!*		bFechaLinx = .T.
*!*	FINALLY
*!*		Release Procedure (ADDBS(strDefaultDir)+_FXP_MOTOR_PROMO)
*!*		ShowProgress()
*!*	ENDTRY

*!*	IF bFechaLinx
*!*		Main.ExitCommand()
*!*		Quit
*!*		Clear Events
*!*	ENDIF


*** Colocar no metodo CarregaParametros

*!*	IF !DODEFAULT() THEN
*!*		RETURN .F.
*!*	ENDIF

*!*	LOCAL bFechaLinx as Boolean, eException as Exception

*!*	bFechaLinx = .F.

*!*	#Define _FXP_MOTOR_PROMO "Userprograms\MotorPromo\startuplinxpos.Fxp"

*!*	IF .Not. File(ADDBS(strDefaultDir)+_FXP_MOTOR_PROMO)
*!*		MsgBox("Arquivo de inicializa��o do motor de promo��es n�o encontrado. Avise Imediatamento o Suporte!",16,"Erro Login")
*!*		bFechaLinx = .T.
*!*	Endif

*!*	Set Procedure To (ADDBS(strDefaultDir)+_FXP_MOTOR_PROMO) Additive

*!*	TRY
*!*		bFechaLinx = .Not.RegistrarComponentesHering()

*!*	CATCH TO eException
*!*		MsgBox("Falha na inicializa��o do motor de promo��es.\nErro: "+eException.Message+"\n\nAvise Imediatamento o Suporte",16,"Erro ExecuteTasks")
*!*		bFechaLinx = .T.
*!*	FINALLY
*!*		Release Procedure (ADDBS(strDefaultDir)+_FXP_MOTOR_PROMO)
*!*		ShowProgress()
*!*	ENDTRY

*!*	IF bFechaLinx
*!*		Main.ExitCommand()
*!*		Quit
*!*		Clear Events
*!*	ENDIF



Procedure RegistrarComponentesHering

	strDllName = "Hering.CRM.Foxpro.dll"
	strPathDll = Addbs(strDefaultDir)+"Userprograms\MotorPromo\Components\" + strDllName
	strDestinyPath = Addbs(strShareddir) + strDllName
	Try
		IF .Not. File(strPathDll)
			MsgBox("Falha no registro da DLL.\nArquivo n�o encontrado em "+strPathDll,16,"Erro no checagem da DLL do Motor")
			Return .f.
		Endif
		
		If !File(strDestinyPath) Or (Main.StringBuffer.MD5FileHash(strPathDll) != Main.StringBuffer.MD5FileHash(strDestinyPath))
			RemoveDllCommonFiles(strDllName)

			oFsCopy = Createobject("Scripting.FileSystemObject")
			oFsCopy.CopyFile(strPathDll, strDestinyPath)
			oFsCopy = Null

			RegistrarDllDotNet(strDllName , strDestinyPath,.T.)
		ENDIF
	Catch To oError
		Try
			RemoveDllCommonFiles(strDllName)
		Catch To oErrorDelete

		Endtry
		Msgbox("Erro no m�todo de registro da DLL do sistema de Motor de promo��es.\nAn�lise o log de eventos para identifica��o do erro.", 48, "Avise imediatamento o suporte")
		Main.Events.NewEvent(102, Null, "Erro no registro da DLL do Motor. Erro: "+oError.Message)
	Endtry


*!*		Try
*!*			objCriacaoCRM = Createobject("Hering.CRM.Foxpro")
*!*			objCriacaoCRM = Null
*!*			Main.AddProperty("RegHeringCRMFoxpro", .T.)
*!*		Catch To oError
*!*			Msgbox("Erro na cria��o do objeto do sistema de CRM.\nAn�lise o log de eventos para identifica��o do erro.", 48, "Avise imediatamento o suporte")
*!*			Main.Events.NewEvent(102, Null, "Erro na cria��o do objeto de CRM. Erro: "+oError.Message)
*!*			Main.AddProperty("RegHeringCRMFoxpro", .F.)
*!*		Endtry

	Try
		objCriacaoMotor = Createobject("Hering.Motor.Foxpro")
		objCriacaoMotor = Null
		Main.AddProperty("RegHeringMotorFoxpro", .T.)
	Catch To oError
		Msgbox("Erro na cria��o do objeto do sistema de [Motor Promo��o].\nAn�lise o log de eventos para identifica��o do erro.", 48, "Avise imediatamento o suporte")
		Main.Events.NewEvent(102, Null, "Erro na cria��o do objeto de [Motor Promo��o]. Erro: "+oError.Message)
		Main.AddProperty("RegHeringMotorFoxpro", .F.)
		If Pemstatus(Main,"RegHeringCRMFoxpro",5)
			Main.RegHeringCRMFoxpro = .F.
		Endif
	Endtry

Endproc




Procedure RetornaLocalAsm
	Local lcWinDir, lcFr32,lnCount, lcHighestDir, lnHighestVer,lcName, lnVer, lnI, tcPath

	* Busca o Path do windows
	lcWinDir = Getenv("windir")

	* concatena o Path do windows 32-bit com o endere�o do diretorio do framework
	tcPath = Addbs(lcWinDir) + "Microsoft.NET\Framework"

	lnCount = Adir(laFiles, Addbs(tcPath)+"*.*" , "D")&&Monta o contador

	Local sRegAsm As String
	lcHighestDir = ""
	lnHighestVer = 0

	For lnI = 1 To lnCount
		If At("D", laFiles(lnI, 5)) > 0 && laFiles contem o array com as pastas do path do framework e busca pela posi��o do lnI

			* busca os diretorios que iniciam com a letra V
			lcName = Lower(laFiles(lnI, 1))
			If Left(lcName, 1) = "v" And Isdigit(Substr(lcName,2,1)) And At(".", lcName) > 0 && Verifica se a pasta possui uma vers�o do framework
				&&ISDIGIT(SUBSTR(lcName,2,1)) AND AT(".", lcName) > 0
				lnVer = Val(Substr(lcName, 2))
				If lnVer > lnHighestVer &&busca a maior vers�o e guarda o valor na variavel Inver
					lnHighestVer = lnVer
					lcHighestDir = lcName
					If File(tcPath  + "\"+ lcHighestDir + "\RegAsm.Exe") &&Verifica se tem o regasm na vers�o superior, caso n�o tenha mantem o da vers�o anterior
						sRegAsm= tcPath  + "\"+ lcHighestDir + "\RegAsm.Exe" &&Obtem a ultima vers�o do regasm
					Endif
				Endif
			Endif
		Endif
	Endfor

	Return sRegAsm
Endproc

Procedure RegistrarDllDotNet
	Lparameters sComponente As String, sPathDll As String, bRegistra As Boolean

	Local sPathRegAsm As String

	oWsh = Createobject("wscript.shell")
	sPathRegAsm= RetornaLocalAsm()
	**sPathDll=strShareddir + strtran(arControls[intFile, 1],".TLB",".DLL")
	If File(sPathDll)
		If !bRegistra
			lcRunD = sPathRegAsm + " /u "+[ "] + sPathDll + [" ]
			oWsh.Run(lcRunD, 0, .T.)
			*bDesRegistrada  = .T.
		Else
			lcRun = sPathRegAsm + [ "] + sPathDll + [" ] + " /codebase"
			oWsh.Run(lcRun, 0, .T.)
			*lcRunD = sPathRegAsm + " /u "+[ "] + sPathDll + [" ]
			*oWsh.Run(lcRunD, 0, .T.)
			*bLinxDtefDesRegistrada = .T.
		Endif
		Return .T.
	Endif

	Return .F.

Endproc

Procedure RemoveDllCommonFiles()
	Parameters strNameDll

	strPathDelete = Addbs(strShareddir) + strNameDll

	If File(strPathDelete)
		oFSDelete = Createobject("Scripting.FileSystemObject")
		oFSDelete.DeleteFile(strPathDelete)
		sleep(500)
	Endif

Endproc


Procedure HrExisteClasse
	Lparameters strClasseName As String

	Local bExiste As Boolean
	bExiste = .F.


	Try
		objCriacaoTeste = Createobject(strClasseName )
		objCriacaoTeste = Null
		bExiste = .T.
	Catch
	Endtry

	Return bExiste
Endproc
