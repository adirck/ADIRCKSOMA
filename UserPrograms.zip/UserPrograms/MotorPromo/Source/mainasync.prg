lParameters strServer, strDataBase, strAuthSQL, strUser, strPassword, strCodigoFilial

If Pcount()>0
	strUser= Iif(strUser == "{embranco}","",strUser)
	strPassword= Iif(strPassword == "{embranco}","",strPassword)
Endif
SET STEP ON 

Try

	* Conection Properties
	SQLSetprop(0,"DispLogin", 3)
	SQLSetprop(0,"BatchMode", .T.)
	SQLSetprop(0,"Asynchronous", .F.)

	* Dlls
	Declare Integer FindWindow In Win32API String lpClassName, String lpWindowName
	Declare Integer BringWindowToTop In Win32API Integer HWnd
	Declare Integer SendMessage In Win32API Integer HWnd, Integer Msg, Integer WParam, Integer Lparam
	Declare Sleep In kernel32 Integer dwMilliseconds
	Declare Integer GetLastError In kernel32
	Declare Integer CloseHandle In kernel32 Integer Handle
	Declare Integer OpenProcess In kernel32 Integer dwDesiredAccessas, Integer bInheritHandle, Integer dwProcId
	Declare Integer EnumProcesses In psapi String @ lpidProcess, Integer cb, Integer @ cbNeeded
	Declare Integer GetModuleFileNameEx In psapi Integer hProcess, Integer hModule, String ModuleName, Integer nSize
	Declare Integer GetModuleBaseName In psapi Integer hProcess, Integer hModule, String @ lpBaseName, Integer nSize
	Declare Integer EnumProcessModules In psapi Integer hProcess, String @ lphModule, Integer cb, Integer @ cbNeeded


	* Procedures
	Set Date Dmy BRITISH Long
	Set Procedure To "tools" Additive
	Set Classlib To "..\MotorPromo" Additive

	*** set aplication name and description to controls multiples initiations
	_Screen.Caption = "Motor Promo Async"
	_Screen.Name = "MotorPromoAsync"

	If .Not. Pemstatus(_vfp,"DebugMode",5)
		AddProperty(_vfp,"DebugMode",.F.)	&& Rever
	Endif

	*** create objects instances
	LoadObjects()

	*** if exists Parameters - Start Service to executing program (prg)
	If Pcount() == 0 .And. !_vfp.DebugMode
		Local strMsg As String
		strMsg = "Software n�o deve ser executado manualmente"
		AddLog(strMsg )
		Messagebox(strMsg,48,"Motor Promo Async")
		Return .T.
	Endif
	
	
	Data.Server = strServer
	Data.Database = strDataBase
	Data.AuthSQL = .Not.(strAuthSQL=="WINDOWS")
	Data.User = strUser
	Data.Password = strPassword

	*** checks conection - do not stop because if handle negative conection, the aplication should again check
	Data.Connect()

	SaleMotorPromoAsync.CodigoFilial = strCodigoFilial
	SaleMotorPromoAsync.StartAsyncProcesses()

	Data.Disconnect()

Catch To exceptionMaster

	Try
		AddLog("Ocorreu um erro Cr�tico no processo.")
		AddLog("Mensagem: "+exceptionMaster.Message)
		AddLog("LineNo: "+Transform(exceptionMaster.Lineno))
		AddLog("LineContents: "+exceptionMaster.LineContents)
		AddLog("Procedure: "+exceptionMaster.Procedure)
	Catch
	Finally
	Endtry
Finally
Endtry
*Read events
