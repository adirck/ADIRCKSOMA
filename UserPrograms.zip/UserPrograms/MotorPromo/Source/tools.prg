PROCEDURE onError
	Lparameters nError, cMethod, nLine

	SaleMotorPromoAsync.Error(nError, cMethod, nLine)

ENDPROC 

* LoadObjects
Function LoadObjects()
	Public Data as Custom,SaleMotorPromoAsync as Custom
	
	Data = CreateObject("Data")
	SaleMotorPromoAsync = Createobject("SaleMotorPromoAsync")
	
Endfunc

Function FormatText
	Lparameters lTexto As String,	lPar1 As Variant,	lPar2 As Variant,	lPar3 As Variant,	lPar4 As Variant,	lPar5 As Variant,	lPar6 As Variant,	lPar7 As Variant,;
		lPar8 As Variant,	lPar9 As Variant,	lPar10 As Variant,	lPar11 As Variant,	lPar12 As Variant,	lPar13 As Variant,	lPar14 As Variant,;
		lPar15 As Variant,	lPar16 As Variant,	lPar17 As Variant,	lPar18 As Variant,	lPar19 As Variant,	lPar20 As Variant


	Local xTextReturn As String,___i As Integer,bIndiceIniciaZero As Boolean,xValor as String
	bIndiceIniciaZero = (At("{0}",lTexto )>0)
	xTextReturn = lTexto

	*** Special Characters
	xTextReturn = Strtran(xTextReturn,[\n],Chr(13)+Chr(10),1,-1,2)
	*xTextReturn = Strtran(xTextReturn,[\t ],Chr(9))


	For ___i = 1 To Parameters()-1

		xValor = Evaluate([lPar]+Allt(Str(___i)))
		If Vartype(xValor) $ [NDT]
			xValor=Cast(xValor As Varchar(20))
		Endif
		If Vartype(xValor) $ [L]
			xValor=Iif(xValor,[1],[0])
		Endif
		If Isnull(xValor)
			xValor=[Null]
		Endif

		If Vartype(xValor) $ [O] && Formata Objetos
			If Pemstatus(xValor,"BaseClass",5)
				Local strDescricaoObjeto As String
				strDescricaoObjeto = ""
				Do Case
					Case Lower(xValor.BaseClass) == "exception" && Formata Objetos Excecao
						*!* transforma objeto em variavel string com os detalhes
						strDescricaoObjeto = Transform(xValor.ErrorNo)+;
							"-Linha:"+Transform(xValor.Lineno)+;
							"-Mensagem: "+Rtrim(xValor.Message)+;
							" | Comando: "+xValor.LineContents+;
							IIF(Empty(xValor.Details),""," | Detalhes: "+xValor.Details)+;
							IIF(Empty(xValor.Comment),""," | Coment�rio: "+xValor.Comment)
					Case Lower(xValor.BaseClass) == "collection" && Formata Objetos Excecao
						strDescricaoObjeto = "Lista com "+Transform(xValor.Count)+" itens "

						If xValor.Count > 0
							Local _____p As Integer
							strDescricaoObjeto = strDescricaoObjeto + [(1:"]+FormatText([{0}"],xValor.Item(1))
							For _____p = 2 To Iif(xValor.Count > 10,10,xValor.Count)
								strDescricaoObjeto = strDescricaoObjeto + [,]+Transform(_____p)+[:"]+FormatText([{0}"],xValor.Item(_____p))
							Endfor
							If xValor.Count > 10
								strDescricaoObjeto = strDescricaoObjeto + ",ect)"
							Else
								strDescricaoObjeto = strDescricaoObjeto + ")"
							Endif
						Endif

					Otherwise
						strDescricaoObjeto = "[Objeto > "+xValor.BaseClass+Iif(xValor.Class # xValor.BaseClass,"->"+xValor.Class,"")+"]"
				Endcase
				xValor = strDescricaoObjeto
			Else
				xValor = "[Objeto]"
			Endif
		Endif

		xValor = Allt(xValor)
		xTextReturn = Strtran(xTextReturn, [{]+Allt(Str(___i+Iif(bIndiceIniciaZero,-1,0)))+[}],xValor)

	Endfor


	Return xTextReturn	
	
ENDFUNC

Function CloseCursor (lNameCursor As String) As Boolean
	Use In Select(lNameCursor)

	Return .T.
Endfunc

Function isObject(strObjectName as String) as Boolean 
	Return (Type(strObjectName)==[O])
Endfunc


Function isNumeric(varValue As Variant) As Boolean

	If Type("varValue")==[N]
		Return .T.
	Endif

	If Type("varValue")==[C] .And. Type(varValue)=="N"
		Return Empty(Chrtran(varValue,"0123456789.,",""))
	Endif

	Return .F.
Endfunc

Function isEmpty(varParam As Variant) As Boolean
	If Isnull(varParam)
		Return .T.
	Endif

	If Inlist(Type("varParam"),"C","D","N","L")
		If Empty(varParam)
			Return .T.
		Endif
	Else
		If Type("varParam")=="U"
			Return .T.
		Endif
	Endif

	Return .F.
Endfunc


Function checkFile(strFile As String ) As Boolean
	If .Not. File(strFile )
		addLog("checkFile: Arquivo n�o encontrado: "+Nvl(strFile,[(nulo)]))
		Return .F.
	Endif
	Return .T.
Endfun


Function checkDirectory(strFile As String ) As Boolean
	If .Not. Directory(strFile )
		addLog("checkDirectory: Diret�rio n�o encontrado: "+Nvl(strFile,[(nulo)]))
		Return .F.
	Endif
	Return .T.
Endfun

Function checkDir(strDirectory As String ) As Boolean
	Return checkDirectory(strDirectory)
Endfun


Function getFiles(strDirectory as String,strExtension as String ,strFilter as String) as Collection
	Private intFiles as Integer,strDefault as String,colTemporary as Collection,strPath as String 
	Local k as Integer
	colTemporary = CreateObject([cCollection])

	strDefault = Set("Default")
	strPath = Set("Path")
	strExtension = Iif(Empty(strExtension),[*],strExtension)
	strFilter = Iif(Empty(strFilter ),[*],strFilter )
	
	IF directory(strDirectory) && checkDirectory
		Set default to (strDirectory)
		Set path to (strDirectory)
		intFiles = ADir(arTemporary, Allt(strFilter)+[.]+Allt(strExtension))
		
		If intFiles >0
			For k = 1 To Alen(arTemporary,1)
				colTemporary.Add(AddBs(strDirectory) + arTemporary[k,1])
			Endfor
		Endif
		
		Set default to &strDefault.
		Set path to &strPath.
	Endif
	
	Return colTemporary	
Endfunc


FUNCTION CheckConnect
	RETURN .f.
ENDFUNC 


Function SqlSelect as Boolean 
	Lparameters lComando As String,lNomeCursor As String,lDescricaoParaErro as String 
	
	If Type([m.data])==[O]
		If Pcount()==1
			Return m.Data.SQLSelect(lComando)
		Else
			If Pcount()==2
				Return m.Data.SQLSelect(lComando,lNomeCursor)
			Else
				Return m.Data.SQLSelect(lComando,lNomeCursor,lDescricaoParaErro)
			Endif
		Endif
	Endif
	
	IF Empty(lDescricaoParaErro)
		lDescricaoParaErro = []
	Endif
	
	addLog(FormatText([SqlSelect:{0} objeto de conex�o n�o foi encontrado],lDescricaoParaErro))
	
	Return .f.
Endfunc

Function SqlExecute as Boolean 
	Lparameters lComando As String,lDescricaoParaErro as String 
	
	If Type([m.data])==[O]
		If Pcount()==1
			Return m.Data.SqlExecute(lComando )
		Else
			Return m.Data.SqlExecute(lComando,lDescricaoParaErro )
		Endif
	Endif
	
	addLog(FormatText([SqlExecute: objeto de conex�o n�o foi encontrado],lDescricaoParaErro))
	
	Return .f.
			
Endfunc

Function RollbackSQL() as Boolean
	
	If Type([m.data])==[O]
		Return m.Data.RollbackSQL()
	Endif
	
	addLog([RollbackSQL: objeto de conex�o n�o foi encontrado])
	
	Return .f.
	
Endfunc

Function BeginTransactSQL() As Boolean

	If Type([m.data])==[O]
		Return m.Data.BeginTransaction()
	Endif

	addLog([BeginTransactSQL: objeto de conex�o n�o foi encontrado])

	Return .F.

Endfunc

Function CommitSQL() As Boolean

	If Type([m.data])==[O]
		Return m.Data.CommitTransaction()
	Endif

	addLog([CommitSQL: objeto de conex�o n�o foi encontrado])

	Return .F.

ENDFUNC


Function showMessage(strMessage As String,intRecno As Integer,intReccount As Integer) As VOID
	
	If Pcount()==1
		ShowProgress(strMessage)
	Else
		If Pcount()==2
			ShowProgress (strMessage,intRecno)
		Else
			ShowProgress (strMessage,intRecno,intReccount)
		Endif
	Endif

Endfunc

Function MsgBox as Boolean
	lParameters strTexto as String,intType as Integer,strTitulo as String 
	
	*** DoDefault
	IF Type([m.SaleMotorPromoAsync])==[O]
		Return m.SaleMotorPromoAsync.MsgBox(strTexto,intType,strTitulo)
	Endif
	
	Private strMessage as String
		
	IF PCount()<2
		intType = 0
	Endif
	
	intType = intType % 256
	
	strMessage = Iif(Empty(Nvl(strTitulo ,"")),"",Alltrim(strTitulo))
	strMessage = strMessage + Iif(Empty(strMessage) Or Empty(strTexto ),[],[ - ])
	strMessage = strMessage + Iif(Empty(strTexto ),[],Allt(strTexto))
	strMessage = "MsgBox: "+strMessage
	
	Return addLog(strMessage)
	
Endfunc	

Function ShowProgress as Boolean 
	lParameters strMessage as String,intReg1 as Integer,intReg2 as Integer

	If Type([m.SaleMotorPromoAsync])==[O]
		Return m.SaleMotorPromoAsync.ShowProgress(strMessage,intReg1,intReg2)
	Endif
	
	addLog([ShowProgress: objeto principal n�o encontrado])
		
Endfunc


FUNCTION getParameter
	Lparameters strParameter As String

	Private strReturn As String
	strReturn = Null
	If SqlSelect(FormatText([Select valor_atual from parametros where parametro = '{0}'],strParameter),[CurGetParameter],FormatText([Erro ao buscar parametro "{0}".],Nvl(strParameter,[(nulo)])))

		If .Not. Used([CurGetParameter]) .Or. Reccount([CurGetParameter])<>1
			addLog(FormatText([Erro ao buscar parametro "{0}". Parametro nulo ou inv�lido.],Nvl(strParameter,[(nulo)])))
		Else
			Select CurGetParameter
			strReturn = CurGetParameter.valor_atual
			CloseCursor([CurGetParameter])
			If Isnull(strReturn)
				addLog(FormatText([Erro ao buscar parametro "{0}". Parametro nulo.],Nvl(strParameter,[(nulo)])))
			Endif
		Endif

	Endif

	Return strReturn

ENDFUNC 

**--------------------------------------------------------------------------------------**
**		 						Log Functions 											**
**--------------------------------------------------------------------------------------**


Function addLog(strDescription as String ) as Boolean
	Return SaleMotorPromoAsync.addLog(strDescription)
Endfunc

Function setNameLog (strNameLog as String) as Void
	SaleMotorPromoAsync.LogName = Evl(Nvl(strNameLog,[]),Main.LogName)
Endfunc


FUNCTION DisplayError(strDescription as String ) as Boolean
	Return SaleMotorPromoAsync.addLog("Error - " +strDescription)
ENDFUNC

FUNCTION DisplayAlert(strDescription as String ) as Boolean
	Return SaleMotorPromoAsync.addLog("Alert - " +strDescription)
ENDFUNC

FUNCTION ExecuteReport
	LPARAMETERS p1,p2,p3
	
ENDFUNC 
