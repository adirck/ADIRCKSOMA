**

SET CLASSLIB TO "motorpromo.vcx" ADDITIVE

salePromo = CREATEOBJECT("SaleMotorPromo")

salePromo.Test()

salePromo.CalculatePromotion()

RELEASE CLASSLIB "motorpromo.vcx"